<div class="col-md-3 green">
	<div class="stack">
		<h2>Excel</h2>
		<div class="cover">
			<div class="price">
				<span class="old-price"><?php echo CURRENCY.EXCEL_LP_P_R; ?></span>
				<span class="new-price"><?php echo CURRENCY.EXCEL_LP_P; ?></span>
			</div>
			<div class="desc1">
				<h5>
					<span>Surge</span>
					Plus
				</h5>
				<p><strong>3 </strong> Business Card Designs</p>
				<p><strong>3 </strong> Letterhead Designs</p>
				<p><strong>3 </strong> Compliment Slip Designs</p>
			</div>
			<div class="text-center">
				<a class="orange-btn" href="<?php echo base_url('reseller_orders/index/7/'); ?>">
					<span data-hover="Order Now">Order Now</span>
				</a>
			</div>
		</div>
	</div>
</div>