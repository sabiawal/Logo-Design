<div class="guarantee" align="center">
<img src="<?php echo base_url()."assets/images/webdesign/guarantee.jpg"; ?>" alt="Guarantee" title="Guarantee" />

</div>

<div class="sidebar-support" align="center">
<span class="images">
<img src="<?= base_url().'assets/images/webdesign/lst-'.COUNTRY.'.gif'; ?> " alt="<?= COUNTRY. ' Live Support'; ?>" title="<?= COUNTRY. ' Live Support'; ?>" />
</span>
<p><?= PHONE_NO; ?></p>

</div>
    
    