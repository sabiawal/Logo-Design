<!--<div class="copyright">
<a href="<?= site_url('client_panel/copyright')?>"  ><img src="<?= base_url().'assets/images/client/copyright.jpg'?>" alt="Copyright Your Logo Now" title="Copyright Your Logo Now" /></a>
</div>-->