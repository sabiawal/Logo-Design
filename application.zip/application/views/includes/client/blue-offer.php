<div class="blue-img">
<img src="<?php base_url(); ?>assets/images/blue-banner-<?php echo COUNTRY; ?>.jpg" alt="Special Offer" title="Special Offer" />

<span class="text-red text-16"><strong><?php echo $today;?></strong></span>



</div>

<div class="blue-img-link">

<a href="<?php echo site_url('packages'); ?>">See Our Packages</a>

<a href="<?php echo site_url('packages'); ?>">Start Your Logo</a>

<a href="<?php echo site_url('process'); ?>">How It Works</a><br />

<a href="<?php echo site_url('portfolio'); ?>">See Our Portfolio</a>

<a href="<?php echo site_url('charity'); ?>">Read about our charitable work</a>

</div>