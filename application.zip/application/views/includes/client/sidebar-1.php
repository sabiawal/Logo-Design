<div class="best-value">
  <div class="best-value-text">
    <div align="center"><a href="<?php 
if(COUNTRY == 'UK'){
echo site_url('web-site-design/webdesigner-limited-sale/index');}
if(COUNTRY == 'USA'){echo site_url('')."web-site-design/webdesigner-limited-sale/";}
?>"><img src="<?php echo base_url()?>assets/images/webdesign/best-value.jpg" alt="Best Value" title="Best Value" /></a></div>
  </div>
</div>
<div class="live-support">
  <div class="live-support-text" align="center">
    <div align="center" style="margin:0 0 10px 0;">
      <!-- BEGIN ProvideSupport.com Graphics Chat Button Code -->
      <div id="ciz1K7" style="z-index:100;position:absolute"></div>
      <div id="scz1K7" style="display:inline; text-align:center;"> </div>
      <div id="sdz1K7" style="display:none; text-align:center;"></div>
      <script type="text/javascript">var sez1K7=document.createElement("script");sez1K7.type="text/javascript";sez1K7.defer=true;sez1K7.src=(location.protocol.indexOf("https")==0?"https://secure.providesupport.com/image":"http://image.providesupport.com")+"/js/pradyumna/safe-standard.js?ps_h=z1K7\u0026ps_t="+new Date().getTime();document.getElementById("sdz1K7").appendChild(sez1K7)</script>
      <noscript>
      <div style="display:inline; text-align:center">
        <div style="text-align:center"> <a href="http://www.providesupport.com?messenger=pradyumna">Live Support</a></div>
      </div>
      </noscript>
      <!-- END ProvideSupport.com Graphics Chat Button Code -->
    </div>
    <p><span class="text-blue"> Do you have any questions about our Web packages? Click Above for answers.</span> </p>
  </div>
</div>
<div class="awards">
      
      <div class="awards-text">
        <h1>Awards</h1>
        <h2 class="text-red text-bold">American design awards</h2>
        <p><span class="text-red">The American Design Awards was founded in the year 2000 rewarding <span class="text-bold">excellence in design</span> and business.</span> <span class="text-bold"><a href="<?php echo site_url('web-site-design/webdesigner-limited-sale/adaward'); ?>">Read more.</a></span></p>
        <h2 class="text-blue text-bold">Summit international awards</h2>
        <p><span class="text-blue">Throughout its 13 year history, the Summit organization has established itself as one of the premier arbiters of <span class="text-bold"> communication excellence.</span></span><span class="text-bold"> <a href="<?php echo site_url('web-site-design/webdesigner-limited-sale/saward'); ?>">Read more.</a></span></p>
        <h2 class="text-dark-red">Red dot awards</h2>
        <p><span class="text-dark-red">This award ranks among the largest and <span class="text-bold">most renowned design competitions</span> in the world. The red dot design award attracted almost 6,000 submissions from 52 countries in 2006 alone. </span><span class="text-bold"><a href="<?php echo site_url('web-site-design/webdesigner-limited-sale/rdaward'); ?>" >Read more.</a></span> </p>
      </div>
      
    </div>
