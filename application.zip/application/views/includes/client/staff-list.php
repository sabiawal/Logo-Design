<div class="staff-list">
  <div class="staff-list-text">
    <h1>Our Staffs</h1>
    <ul>
      <li>
        <p><a href="mailto:jacob@<?php echo SITE_NAME ?>">jacob@<?php echo SITE_NAME ?></a><br />
          <strong>Jacob smith</strong><br />
          <span class="text-italic">Director of Business Development</span></p>
      </li>
      <li>
        <p><a href="mailto:emma@<?php echo SITE_NAME ?>">emma@<?php echo SITE_NAME ?></a><br />
          <strong>Emma Moore</strong><br />
          <span class="text-italic">Creative Department Manager</span></p>
      </li>
      <li>
        <p><a href="mailto:daniel@<?php echo SITE_NAME ?>">daniel@<?php echo SITE_NAME ?></a><br />
          <strong>Daniel Jones</strong><br />
          <span class="text-italic">Account Manager/Designer</span></p>
      </li>
      <li>
        <p><a href="mailto:will@<?php echo SITE_NAME ?>">will@<?php echo SITE_NAME ?></a><br />
          <strong>Will Johnson</strong><br />
          <span class="text-italic">Account Manager/ Designer</span></p>
      </li>
      <li>
        <p><a href="mailto:ethan@<?php echo SITE_NAME ?>">ethan@<?php echo SITE_NAME ?></a><br />
          <strong>Ethan Brown</strong><br />
          <span class="text-italic">Customer Service/ Designer</span></p>
      </li>
      <li>
        <p><a href="mailto:joshua@<?php echo SITE_NAME ?>">joshua@<?php echo SITE_NAME ?></a><br />
          <strong>Joshua Davis</strong><br />
          <span class="text-italic">Designer /Graphic Artist</span></p>
      </li>
      <li>
        <p><a href="mailto:brad@<?php echo SITE_NAME ?>">brad@<?php echo SITE_NAME ?></a><br />
          <strong>Brad Miller</strong><br />
          <span class="text-italic">Designer /Graphic Artist</span></p>
      </li>
      <li>
        <p><a href="mailto:christina@<?php echo SITE_NAME ?>">christina@<?php echo SITE_NAME ?></a><br />
          <strong>Christina Wilson</strong><br />
          <span class="text-italic">Designer /Graphic Artist</span></p>
      </li>
      <li>
        <p><a href="mailto:anthony@<?php echo SITE_NAME ?>">anthony@<?php echo SITE_NAME ?></a><br />
          <strong>Anthony Taylor</strong><br />
          <span class="text-italic">Designer /Graphic Artist</span></p>
      </li>
      <li>
        <p><a href="mailto:william@<?php echo SITE_NAME ?>">william@<?php echo SITE_NAME ?></a><br />
          <strong>Willaim Martin</strong><br />
          <span class="text-italic">Designer /Graphic Artist</span></p>
      </li>
      <li>
        <p><a href="mailto:george@<?php echo SITE_NAME ?>">george@<?php echo SITE_NAME ?></a><br />
          <strong>George Thomas</strong><br />
          <span class="text-italic">Designer /Graphic Artist</span></p>
      </li>
      <li>
        <p><a href="mailto:sophia@<?php echo SITE_NAME ?>">sophia@<?php echo SITE_NAME ?></a><br />
          <strong>Sophia Harris</strong><br />
          <span class="text-italic">Designer /Graphic Artist</span></p>
      </li>
      <li>
        <p><a href="mailto:matthew@<?php echo SITE_NAME ?>">matthew@<?php echo SITE_NAME ?></a><br />
          <strong>Matthew Clark</strong><br />
          <span class="text-italic">Designer /Graphic Artist</span></p>
      </li>
      <li>
        <p><a href="mailto:micheal@<?php echo SITE_NAME ?>">micheal@<?php echo SITE_NAME ?></a><br />
          <strong>Micheal Lee</strong><br />
          <span class="text-italic">Designer /Graphic Artist</span></p>
      </li>
      <li>
        <p><a href="mailto:olivia@<?php echo SITE_NAME ?>">olivia@<?php echo SITE_NAME ?></a><br />
          <strong>Olivia Jolie</strong><br />
          <span class="text-italic">Designer</span></p>
      </li>
      <li>
        <p><a href="mailto:kevin@<?php echo SITE_NAME ?>">kevin@<?php echo SITE_NAME ?></a><br />
          <strong>Kevin Robinson</strong><br />
          <span class="text-italic">Designer</span></p>
      </li>
      <li>
        <p><a href="mailto:hillarry@<?php echo SITE_NAME ?>">hillarry@<?php echo SITE_NAME ?></a><br />
          <strong>Hillarry Jones</strong><br />
          <span class="text-italic">Designer</span></p>
      </li>
      <li>
        <p><a href="mailto:david@<?php echo SITE_NAME ?>">david@<?php echo SITE_NAME ?></a><br />
          <strong>David Walker</strong><br />
          <span class="text-italic">Designer</span></p>
      </li>
      <li>
        <p><a href="mailto:elizabeth@<?php echo SITE_NAME ?>">elizabeth@<?php echo SITE_NAME ?></a><br />
          <strong>Elizabeth Collins</strong><br />
          <span class="text-italic">Designer</span></p>
      </li>
      <li>
        <p><a href="mailto:emily@<?php echo SITE_NAME ?>">emily@<?php echo SITE_NAME ?></a><br />
          <strong>Emily Watson</strong><br />
          <span class="text-italic">Designer</span></p>
      </li>
      <li>
        <p><a href="mailto:chris@<?php echo SITE_NAME ?>">chris@<?php echo SITE_NAME ?></a><br />
          <strong>Christopher wood</strong><br />
          <span class="text-italic">Designer</span></p>
      </li>
      <li>
        <p><a href="mailto:angela@<?php echo SITE_NAME ?>">angela@<?php echo SITE_NAME ?></a><br />
          <strong>Angela Diaz</strong><br />
          <span class="text-italic">Sales/Support</span></p>
      </li>
    </ul>
  </div>
</div>
