<div align="center" class="seal-top-all"><p>Call us TOLL FREE<br />
  
   <span class="adinsightNumber2593"><?= PHONE_NO; ?></span> </p></div>