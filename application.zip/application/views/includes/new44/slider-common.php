			<?php 
            if($this->router->fetch_class() == 'new44'):  // checking controller name
            ?>            
            <section id="inner-cont-banner">
				<div class="container">
					<div class="row">
						<div class="col-xs-12">
							<div class="inner-banner">
								<img src="assets/images/guarantee-banner.jpg" alt="guarantee" width="1140" height="367"/>
								<div class="right-align-ban-caption">
									<div class="banner-caption-head">
										<h2>
											You can count on us!
										</h2>
									</div>
									<div class="banner-desc">
										<?php /*?><p>
											<?php echo GUARANTEE_DAYS; ?> Day, 100% Money Back Guarantee
										</p>
										<p>
											Refund available at any time
										</p>
										<p>
											No Questions. No Fees.
										</p>
										<a class="button" href="<?php echo site_url('packages'); ?>">Get Started</a><?php */?>
                                        <p>Phone contact with your designers</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>            
            <?php endif; ?>