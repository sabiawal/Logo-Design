            <section class="normal-desc-box normal-gray-box">
				<div class="container">
					<div class="row">
                        
						<div class="col-md-9 auto-center" id="package-super-WS">
							<div class="left">
								<div class="top">
									<p><b style="text-decoration: line-through;"><?php echo CURRENCY.LOGO_COPYRIGHT_P; ?></b><span> FREE </span> Copyright Legal Certificate</p>
									<p><b style="text-decoration: line-through;"><?php echo CURRENCY.LOGO_ALTERNATION_P; ?></b><span> FREE </span> Lifetime Alterations to your Logo</p>
								</div>
								<span class="include">Included in All Logo Packages</span>
							</div>
							<div class="right">
								<p class="red">Ends <?php echo $today; ?></p>
								<div class="fact-box text-center">
									<h5>Fact</h5>
									<p>
										The Best Logo Offer 
										<br>
										you'll Ever Find
									</p>

								</div>
							</div>
							<h3 class="super-w-title">Super winter sale</h3>
						</div>
					</div>
				</div>
			</section>