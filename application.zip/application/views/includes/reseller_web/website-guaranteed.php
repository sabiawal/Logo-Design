<h3>Remember, your website is guaranteed to have 99.9% uptime, the very best you can get...</h3>
<div class="scroll-cover">
	<div class="hosting-scroll-fixed clearfix">
		<table class="websites-guarantee" cellpadding="0" cellspacing="0" width="100%">
			<thead>
				<tr>
					<th>Availability %</th>
					<th>Downtime per year</th>
					<th>Downtime per month</th>
					<th>Downtime per week</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>90%</td>
					<td>36.5 days</td>
					<td>72 hours</td>
					<td>16.8 hours</td>
				</tr>
				<tr>
					<td>95%</td>
					<td>18.25 days</td>
					<td>36 hours</td>
					<td>8.4 hours</td>
				</tr>
				<tr>
					<td>97%</td>
					<td>10.96 days</td>
					<td>21.6 hours</td>
					<td>5.04 hours</td>
				</tr>
				<tr>
					<td>98%</td>
					<td>7.3 days</td>
					<td>14.4 hours</td>
					<td>3.36 hours</td>
				</tr>
				<tr>
					<td>99%</td>
					<td>3.65 days</td>
					<td>7.2 hours</td>
					<td>1.68 hours</td>
				</tr>
				<tr>
					<td>99.5%</td>
					<td>1.83 days</td>
					<td>3.6 hours</td>
					<td>50.4 minutes</td>
				</tr>
				<tr>
					<td>99.8%</td>
					<td>17.52 hours</td>
					<td>86.23 minutes</td>
					<td>20.16 minutes</td>
				</tr>
				<tr>
					<td>99.9%</td>
					<td>31.5 seconds</td>
					<td>2.59 seconds</td>
					<td>0.605 seconds</td>
				</tr>
			</tbody>
		</table>
	</div>
</div>
