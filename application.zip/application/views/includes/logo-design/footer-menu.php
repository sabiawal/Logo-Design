<ul>
<li><a href="<?php echo base_url();?>">Home</a></li>
<li><a href="<?php echo site_url('packages'); ?>">Packages</a></li>
<li><a href="<?php echo site_url('process'); ?>">Design Process</a></li>
<li><a href="<?php echo site_url('portfolio'); ?>">Portfolio</a></li>
<li><a href="<?php echo site_url('portfolio'); ?>">Testimonials</a></li>
<li><a href="<?php echo site_url('faq'); ?>">FAQ</a></li>
<li><a href="<?php echo site_url('terms'); ?>">Terms &amp; Conditions</a></li>
<li><a href="<?php echo site_url('privacypolicy'); ?>">Privacy policy</a></li>
<li><a href="<?php echo site_url('contact'); ?>">Contact</a></li>
</ul>