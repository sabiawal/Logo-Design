<div class="payment_seals" align="center">
<p>
<?php if($this->router->method != "index"){ ?>
<img src="<?= base_url()?>assets/images/mbg-seals.jpg" alt="We give best Money Back Gaurantee" title="We give best Money Back Gaurantee" align="absmiddle" />
<?php } ?>
<span>We Accept</span>
<a href="javascript:void(0)"><img src="<?= base_url()?>assets/images/cards/american-express.gif" alt="We accept American Express" title="We accept American Express" align="absmiddle" /></a>
<a href="javascript:void(0)"><img src="<?= base_url()?>assets/images/cards/visa.gif" alt="We accept Visa" title="We accept Visa" align="absmiddle" /></a>
<a href="javascript:void(0)"><img src="<?= base_url()?>assets/images/cards/mastercard.gif" alt="We accept Master Card" title="We accept Master Card" align="absmiddle" /></a>
<a href="javascript:void(0)"><img src="<?= base_url()?>assets/images/cards/discover.gif" alt="We accept Discover" title="We accept Discover" align="absmiddle" /></a>
<a href="javascript:void(0)"><img src="<?= base_url()?>assets/images/cards/paypal.gif" alt="We accept PayPal" title="We accept PayPal" align="absmiddle" /></a>
<a href="javascript:void(0)"><img src="<?= base_url()?>assets/images/cards/verified-visa.gif" alt="We are Visa Verified" title="We are Visa Verified" align="absmiddle" /></a>
<a href="javascript:void(0)"><img src="<?= base_url()?>assets/images/cards/mastercard-secure.gif" alt="Secure Mastercard Transaction" title="Secure Mastercard Transaction" align="absmiddle" /></a>
<?php if($this->router->method != "index"){ ?>
<img src="<?= base_url()?>assets/images/mbg-seals.jpg" alt="We give best Money Back Gaurantee" title="We give best Money Back Gaurantee" align="absmiddle" />
<?php } ?>
</p>
</div>