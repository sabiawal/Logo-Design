<?php 
                            if(isset($value))
                  			{
		                  		$value = str_replace('-',' ',$value);
		                  		
		                  		
		                  		
		                  		
                  			if($value == "Accounting Logo Design")
		                  		{ ?>

<ul class="ad-thumb-list">
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Accounting-Logo-Design/1.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Accounting-Logo-Design/thumbs/1.jpg" class="image0" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Accounting-Logo-Design/2.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Accounting-Logo-Design/thumbs/2.jpg"  class="image1" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Accounting-Logo-Design/3.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Accounting-Logo-Design/thumbs/3.jpg"  class="image2" /> </a> </li>
</ul>
<?php }
		                  		
		                  		if($value == "Church and Religious Logo Design")
		                  		{ ?>

<ul class="ad-thumb-list">
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Church-and-Religious-Logo-Design/1.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Church-and-Religious-Logo-Design/thumbs/1.jpg" class="image0" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Church-and-Religious-Logo-Design/2.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Church-and-Religious-Logo-Design/thumbs/2.jpg"  class="image1" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Church-and-Religious-Logo-Design/3.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Church-and-Religious-Logo-Design/thumbs/3.jpg"  class="image2" /> </a> </li>
</ul>
<?php }

                  			if($value == "Attorney and Legal Logo Design")
		                  		{ ?>

<ul class="ad-thumb-list">
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Attorney-and-Legal-Logo-Design/1.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Attorney-and-Legal-Logo-Design/thumbs/1.jpg" class="image0" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Attorney-and-Legal-Logo-Design/2.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Attorney-and-Legal-Logo-Design/thumbs/2.jpg"  class="image1" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Attorney-and-Legal-Logo-Design/3.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Attorney-and-Legal-Logo-Design/thumbs/3.jpg"  class="image2" /> </a> </li>
</ul>
<?php }

if($value == "Biotechnology and Pharmaceutical Logo Design")
		                  		{ ?>

<ul class="ad-thumb-list">
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Biotechnology-and-Pharmaceutical-Logo-Design/1.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Biotechnology-and-Pharmaceutical-Logo-Design/thumbs/1.jpg" class="image0" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Biotechnology-and-Pharmaceutical-Logo-Design/2.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Biotechnology-and-Pharmaceutical-Logo-Design/thumbs/2.jpg"  class="image1" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Biotechnology-and-Pharmaceutical-Logo-Design/3.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Biotechnology-and-Pharmaceutical-Logo-Design/thumbs/3.jpg"  class="image2" /> </a> </li>
</ul>
<?php }

                  			if($value == "Automotive Logo Design")
		                  		{ ?>

<ul class="ad-thumb-list">
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Automotive-Logo-Design/1.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Automotive-Logo-Design/thumbs/1.jpg" class="image0" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Automotive-Logo-Design/2.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Automotive-Logo-Design/thumbs/2.jpg"  class="image1" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Automotive-Logo-Design/3.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Automotive-Logo-Design/thumbs/3.jpg"  class="image2" /> </a> </li>
</ul>
<?php }

                  			if($value == "Consulting Logo Design")
		                  		{ ?>

<ul class="ad-thumb-list">
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Consulting-Logo-Design/1.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Consulting-Logo-Design/thumbs/1.jpg" class="image0" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Consulting-Logo-Design/2.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Consulting-Logo-Design/thumbs/2.jpg"  class="image1" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Consulting-Logo-Design/3.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Consulting-Logo-Design/thumbs/3.jpg"  class="image2" /> </a> </li>
</ul>
<?php }



                  			if($value == "Dental Logo Design")
		                  		{ ?>

<ul class="ad-thumb-list">
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Dental-Logo-Design/1.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Dental-Logo-Design/thumbs/1.jpg" class="image0" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Dental-Logo-Design/2.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Dental-Logo-Design/thumbs/2.jpg"  class="image1" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Dental-Logo-Design/3.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Dental-Logo-Design/thumbs/3.jpg"  class="image2" /> </a> </li>
</ul>
<?php }

		                  		
		         
		                  		
                  			if($value == "Construction Logo Design")
		                  		{ ?>

<ul class="ad-thumb-list">
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Construction-Logo-Design/1.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Construction-Logo-Design/thumbs/1.jpg" class="image0" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Construction-Logo-Design/2.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Construction-Logo-Design/thumbs/2.jpg"  class="image1" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Construction-Logo-Design/3.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Construction-Logo-Design/thumbs/3.jpg"  class="image2" /> </a> </li>
</ul>
<?php }
		                  		
                  			if($value == "Education Logo Design")
		                  		{ ?>

<ul class="ad-thumb-list">
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Education-Logo-Design/1.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Education-Logo-Design/thumbs/1.jpg" class="image0" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Education-Logo-Design/2.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Education-Logo-Design/thumbs/2.jpg"  class="image1" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Education-Logo-Design/3.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Education-Logo-Design/thumbs/3.jpg"  class="image2" /> </a> </li>
</ul>
<?php }




                  			if($value == "Entertainment Logo Design")
		                  		{ ?>

<ul class="ad-thumb-list">
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Entertainment-Logo-Design/1.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Entertainment-Logo-Design/thumbs/1.jpg" class="image0" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Entertainment-Logo-Design/2.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Entertainment-Logo-Design/thumbs/2.jpg"  class="image1" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Entertainment-Logo-Design/3.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Entertainment-Logo-Design/thumbs/3.jpg"  class="image2" /> </a> </li>
</ul>
<?php }



                  			if($value == "Event Logo Design")
		                  		{ ?>

<ul class="ad-thumb-list">
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Event-Logo-Design/1.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Event-Logo-Design/thumbs/1.jpg" class="image0" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Event-Logo-Design/2.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Event-Logo-Design/thumbs/2.jpg"  class="image1" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Event-Logo-Design/3.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Event-Logo-Design/thumbs/3.jpg"  class="image2" /> </a> </li>
</ul>
<?php }



                  			if($value == "Financial Services Logo Design")
		                  		{ ?>

<ul class="ad-thumb-list">
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Financial-Services-Logo-Design/1.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Financial-Services-Logo-Design/thumbs/1.jpg" class="image0" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Financial-Services-Logo-Design/2.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Financial-Services-Logo-Design/thumbs/2.jpg"  class="image1" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Financial-Services-Logo-Design/3.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Financial-Services-Logo-Design/thumbs/3.jpg"  class="image2" /> </a> </li>
</ul>
<?php }



                  			if($value == "Golf Courses Logo Design")
		                  		{ ?>

<ul class="ad-thumb-list">
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Golf-Courses-Logo-Design/1.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Golf-Courses-Logo-Design/thumbs/1.jpg" class="image0" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Golf-Courses-Logo-Design/2.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Golf-Courses-Logo-Design/thumbs/2.jpg"  class="image1" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Golf-Courses-Logo-Design/3.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Golf-Courses-Logo-Design/thumbs/3.jpg"  class="image2" /> </a> </li>
</ul>
<?php }


                  			if($value == "High Tech Logo Design")
		                  		{ ?>

<ul class="ad-thumb-list">
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/High-Tech-Logo-Design/1.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/High-Tech-Logo-Design/thumbs/1.jpg" class="image0" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/High-Tech-Logo-Design/2.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/High-Tech-Logo-Design/thumbs/2.jpg"  class="image1" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/High-Tech-Logo-Design/3.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/High-Tech-Logo-Design/thumbs/3.jpg"  class="image2" /> </a> </li>
</ul>
<?php }
		                  		
		                  		
		                  		if($value == "Illustrative Logo Design")
		                  		{ ?>

<ul class="ad-thumb-list">
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Illustrative-Logo-Design/1.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Illustrative-Logo-Design/thumbs/1.jpg" class="image0" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Illustrative-Logo-Design/2.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Illustrative-Logo-Design/thumbs/2.jpg"  class="image1" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Illustrative-Logo-Design/3.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Illustrative-Logo-Design/thumbs/3.jpg"  class="image2" /> </a> </li>
</ul>
<?php }





                  			if($value == "International Logo Design")
		                  		{ ?>

<ul class="ad-thumb-list">
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/International-Logo-Design/1.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/International-Logo-Design/thumbs/1.jpg" class="image0" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/International-Logo-Design/2.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/International-Logo-Design/thumbs/2.jpg"  class="image1" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/International-Logo-Design/3.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/International-Logo-Design/thumbs/3.jpg"  class="image2" /> </a> </li>
</ul>
<?php }




                  			if($value == "Internet Logo Design")
		                  		{ ?>

<ul class="ad-thumb-list">
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Internet-Logo-Design/1.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Internet-Logo-Design/thumbs/1.jpg" class="image0" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Internet-Logo-Design/2.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Internet-Logo-Design/thumbs/2.jpg"  class="image1" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Internet-Logo-Design/3.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Internet-Logo-Design/thumbs/3.jpg"  class="image2" /> </a> </li>
</ul>
<?php }


                  			if($value == "Landscaping Logo Design")
		                  		{ ?>

<ul class="ad-thumb-list">
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Landscaping-Logo-Design/1.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Landscaping-Logo-Design/thumbs/1.jpg" class="image0" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Landscaping-Logo-Design/2.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Landscaping-Logo-Design/thumbs/2.jpg"  class="image1" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Landscaping-Logo-Design/3.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Landscaping-Logo-Design/thumbs/3.jpg"  class="image2" /> </a> </li>
</ul>
<?php }



		                  			if($value == "Medical Logo Design")
		                  		{ ?>
<ul class="ad-thumb-list">
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Medical-Logo-Design/1.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Medical-Logo-Design/thumbs/1.jpg" class="image0" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Medical-Logo-Design/2.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Medical-Logo-Design/thumbs/2.jpg"  class="image1" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Medical-Logo-Design/3.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Medical-Logo-Design/thumbs/3.jpg"  class="image2" /> </a> </li>
</ul>
<?php }


                  			
		                  			if($value == "Networking Logo Design")
		                  		{ ?>
<ul class="ad-thumb-list">
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Networking-Logo-Design/1.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Networking-Logo-Design/thumbs/1.jpg" class="image0" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Networking-Logo-Design/2.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Networking-Logo-Design/thumbs/2.jpg"  class="image1" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Networking-Logo-Design/3.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Networking-Logo-Design/thumbs/3.jpg"  class="image2" /> </a> </li>
</ul>
<?php }


                  			if($value == "Pool and Spa Logo Design")
		                  		{ ?>
<ul class="ad-thumb-list">
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Pool-and-Spa-Logo-Design/1.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Pool-and-Spa-Logo-Design/thumbs/1.jpg" class="image0" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Pool-and-Spa-Logo-Design/2.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Pool-and-Spa-Logo-Design/thumbs/2.jpg"  class="image1" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Pool-and-Spa-Logo-Design/3.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Pool-and-Spa-Logo-Design/thumbs/3.jpg"  class="image2" /> </a> </li>
</ul>
<?php }




                  			if($value == "Real Estate Development Logo Design")
		                  		{ ?>

<ul class="ad-thumb-list">
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Real-Estate-Development-Logo-Design/1.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Real-Estate-Development-Logo-Design/thumbs/1.jpg" class="image0" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Real-Estate-Development-Logo-Design/2.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Real-Estate-Development-Logo-Design/thumbs/2.jpg"  class="image1" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Real-Estate-Development-Logo-Design/3.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Real-Estate-Development-Logo-Design/thumbs/3.jpg"  class="image2" /> </a> </li>
</ul>
<?php }


                  			if($value == "Realtor Logo Design")
		                  		{ ?>

<ul class="ad-thumb-list">
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Realtor-Logo-Design/1.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Realtor-Logo-Design/thumbs/1.jpg" class="image0" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Realtor-Logo-Design/2.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Realtor-Logo-Design/thumbs/2.jpg"  class="image1" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Realtor-Logo-Design/3.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Realtor-Logo-Design/thumbs/3.jpg"  class="image2" /> </a> </li>
</ul>
<?php }




                  			
                  			if($value == "Restaurant Logo Design")
		                  		{ ?>

<ul class="ad-thumb-list">
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Restaurant-Logo-Design/1.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Restaurant-Logo-Design/thumbs/1.jpg" class="image0" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Restaurant-Logo-Design/2.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Restaurant-Logo-Design/thumbs/2.jpg"  class="image1" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Restaurant-Logo-Design/3.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Restaurant-Logo-Design/thumbs/3.jpg"  class="image2" /> </a> </li>
</ul>
<?php }
		                  		
		                  		
		                  		 
		                  		if($value == "Retail Logo Design")
		                  		{ ?>

<ul class="ad-thumb-list">
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Retail-Logo-Design/1.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Retail-Logo-Design/thumbs/1.jpg" class="image0" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Retail-Logo-Design/2.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Retail-Logo-Design/thumbs/2.jpg"  class="image1" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Retail-Logo-Design/3.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Retail-Logo-Design/thumbs/3.jpg"  class="image2" /> </a> </li>
</ul>
<?php }

                  			if($value == "Salon Day Spa Logo Design")
		                  		{ ?>

<ul class="ad-thumb-list">
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Salon-Day-Spa-Logo-Design/1.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Salon-Day-Spa-Logo-Design/thumbs/1.jpg" class="image0" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Salon-Day-Spa-Logo-Design/2.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Salon-Day-Spa-Logo-Design/thumbs/2.jpg"  class="image1" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Salon-Day-Spa-Logo-Design/3.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Salon-Day-Spa-Logo-Design/thumbs/3.jpg"  class="image2" /> </a> </li>
</ul>
<?php }



	                      		
                  			if($value == "Service Industries Logo Design")
		                  		{ ?>
<ul class="ad-thumb-list">
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Service-Industries-Logo-Design/1.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Service-Industries-Logo-Design/thumbs/1.jpg" class="image0" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Service-Industries-Logo-Design/2.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Service-Industries-Logo-Design/thumbs/2.jpg"  class="image1" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Service-Industries-Logo-Design/3.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Service-Industries-Logo-Design/thumbs/3.jpg"  class="image2" /> </a> </li>
</ul>
<?php }



                  			if($value == "Travel Logo Design")
		                  		{ ?>
<ul class="ad-thumb-list">
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Travel-Logo-Design/1.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Travel-Logo-Design/thumbs/1.jpg" class="image0" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Travel-Logo-Design/2.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Travel-Logo-Design/thumbs/2.jpg"  class="image1" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Travel-Logo-Design/3.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Travel-Logo-Design/thumbs/3.jpg"  class="image2" /> </a> </li>
</ul>
<?php }




if($value == "Off The Wall Logo Design")
		                  		{ ?>

<ul class="ad-thumb-list">
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Off-The-Wall-Logo-Design/1.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Off-The-Wall-Logo-Design/thumbs/1.jpg" class="image0" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Off-The-Wall-Logo-Design/2.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Off-The-Wall-Logo-Design/thumbs/2.jpg"  class="image1" /> </a> </li>
  <li> <a href="<?php echo base_url()?>images/logos-by-industry/Off-The-Wall-Logo-Design/3.jpg"> <img src="<?php echo base_url()?>images/logos-by-industry/Off-The-Wall-Logo-Design/thumbs/3.jpg"  class="image2" /> </a> </li>
</ul>
<?php }

                  			
                  			
                  			}?>
