<div align="center" class="seal-top-all"><p>Call us TOLL FREE<br />
   <span><?= PHONE_NO; ?></span></p></div>