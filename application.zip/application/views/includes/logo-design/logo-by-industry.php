<?php 
                            if(isset($value))
                  			{
		                  		$value = str_replace('-',' ',$value);
		                  		
                  			if($value == "Accounting Logo Design")
		                  		{ ?>

<table class="" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td colspan="0"><div>
          <div class="bigPic" style="height:255px; width:936px;"> <img src="<?php echo base_url()?>images/logos-by-industry/Accounting-Logo-Design/1.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Accounting-Logo-Design/2.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Accounting-Logo-Design/3.jpg"> </div>
          <div class="thumbs" style="display:block;">
            <ul style="width: 1476px;">
              <li class="" rel="1"><img src="<?php echo base_url()?>images/logos-by-industry/Accounting-Logo-Design/thumbs/1.jpg"></li>
              <li class="" rel="2"><img src="<?php echo base_url()?>images/logos-by-industry/Accounting-Logo-Design/thumbs/2.jpg"></li>
              <li class="" rel="3"><img src="<?php echo base_url()?>images/logos-by-industry/Accounting-Logo-Design/thumbs/3.jpg"></li>
              
            </ul>
          </div>
        </div></td>
    </tr>
  </tbody>
</table>
<?php }
		                  		
		                  		if($value == "Church and Religious Logo Design")
		                  		{ ?>

<table class="" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td colspan="0"><div>
          <div class="bigPic" style="height:255px; width:936px;"> <img src="<?php echo base_url()?>images/logos-by-industry/Church-and-Religious-Logo-Design/1.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Church-and-Religious-Logo-Design/2.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Church-and-Religious-Logo-Design/3.jpg"> </div>
          <div class="thumbs" style="display:block;">
            <ul style="width: 1476px;">
              <li class="" rel="1"><img src="<?php echo base_url()?>images/logos-by-industry/Church-and-Religious-Logo-Design/thumbs/1.jpg"></li>
              <li class="" rel="2"><img src="<?php echo base_url()?>images/logos-by-industry/Church-and-Religious-Logo-Design/thumbs/2.jpg"></li>
              <li class="" rel="3"><img src="<?php echo base_url()?>images/logos-by-industry/Church-and-Religious-Logo-Design/thumbs/3.jpg"></li>
              
            </ul>
          </div>
        </div></td>
    </tr>
  </tbody>
</table>
<?php }

                  			if($value == "Attorney and Legal Logo Design")
		                  		{ ?>

<table class="" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td colspan="0"><div>
          <div class="bigPic" style="height:255px; width:936px;"> <img src="<?php echo base_url()?>images/logos-by-industry/Attorney-and-Legal-Logo-Design/1.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Attorney-and-Legal-Logo-Design/2.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Attorney-and-Legal-Logo-Design/3.jpg"> </div>
          <div class="thumbs" style="display:block;">
            <ul style="width: 1476px;">
              <li class="" rel="1"><img src="<?php echo base_url()?>images/logos-by-industry/Attorney-and-Legal-Logo-Design/thumbs/1.jpg"></li>
              <li class="" rel="2"><img src="<?php echo base_url()?>images/logos-by-industry/Attorney-and-Legal-Logo-Design/thumbs/2.jpg"></li>
              <li class="" rel="3"><img src="<?php echo base_url()?>images/logos-by-industry/Attorney-and-Legal-Logo-Design/thumbs/3.jpg"></li>
              
            </ul>
          </div>
        </div></td>
    </tr>
  </tbody>
</table>
<?php }

                  			if($value == "Automotive Logo Design")
		                  		{ ?>

<table class="" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td colspan="0"><div>
          <div class="bigPic" style="height:255px; width:936px;"> <img src="<?php echo base_url()?>images/logos-by-industry/Automotive-Logo-Design/1.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Automotive-Logo-Design/2.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Automotive-Logo-Design/3.jpg"> </div>
          <div class="thumbs" style="display:block;">
            <ul style="width: 1476px;">
              <li class="" rel="1"><img src="<?php echo base_url()?>images/logos-by-industry/Automotive-Logo-Design/thumbs/1.jpg"></li>
              <li class="" rel="2"><img src="<?php echo base_url()?>images/logos-by-industry/Automotive-Logo-Design/thumbs/2.jpg"></li>
              <li class="" rel="3"><img src="<?php echo base_url()?>images/logos-by-industry/Automotive-Logo-Design/thumbs/3.jpg"></li>
              
            </ul>
          </div>
        </div></td>
    </tr>
  </tbody>
</table>
<?php }


                  			if($value == "Biotechnology and Pharmaceutical Logo Design")
		                  		{ ?>

<table class="" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td colspan="0"><div>
          <div class="bigPic" style="height:255px; width:936px;"> <img src="<?php echo base_url()?>images/logos-by-industry/Biotechnology-and-Pharmaceutical-Logo-Design/1.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Biotechnology-and-Pharmaceutical-Logo-Design/2.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Biotechnology-and-Pharmaceutical-Logo-Design/3.jpg"> </div>
          <div class="thumbs" style="display:block;">
            <ul style="width: 1476px;">
              <li class="" rel="1"><img src="<?php echo base_url()?>images/logos-by-industry/Biotechnology-and-Pharmaceutical-Logo-Design/thumbs/1.jpg"></li>
              <li class="" rel="2"><img src="<?php echo base_url()?>images/logos-by-industry/Biotechnology-and-Pharmaceutical-Logo-Design/thumbs/2.jpg"></li>
              <li class="" rel="3"><img src="<?php echo base_url()?>images/logos-by-industry/Biotechnology-and-Pharmaceutical-Logo-Design/thumbs/3.jpg"></li>
              
            </ul>
          </div>
        </div></td>
    </tr>
  </tbody>
</table>
<?php }

                  			if($value == "Consulting Logo Design")
		                  		{ ?>

<table class="" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td colspan="0"><div>
          <div class="bigPic" style="height:255px; width:936px;"> <img src="<?php echo base_url()?>images/logos-by-industry/Consulting-Logo-Design/1.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Consulting-Logo-Design/2.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Consulting-Logo-Design/3.jpg"> </div>
          <div class="thumbs" style="display:block;">
            <ul style="width: 1476px;">
              <li class="" rel="1"><img src="<?php echo base_url()?>images/logos-by-industry/Consulting-Logo-Design/thumbs/1.jpg"></li>
              <li class="" rel="2"><img src="<?php echo base_url()?>images/logos-by-industry/Consulting-Logo-Design/thumbs/2.jpg"></li>
              <li class="" rel="3"><img src="<?php echo base_url()?>images/logos-by-industry/Consulting-Logo-Design/thumbs/3.jpg"></li>
              
            </ul>
          </div>
        </div></td>
    </tr>
  </tbody>
</table>
<?php }



                  			if($value == "Dental Logo Design")
		                  		{ ?>

<table class="" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td colspan="0"><div>
          <div class="bigPic" style="height:255px; width:936px;"> <img src="<?php echo base_url()?>images/logos-by-industry/Dental-Logo-Design/1.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Dental-Logo-Design/2.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Dental-Logo-Design/3.jpg"> </div>
          <div class="thumbs" style="display:block;">
            <ul style="width: 1476px;">
              <li class="" rel="1"><img src="<?php echo base_url()?>images/logos-by-industry/Dental-Logo-Design/thumbs/1.jpg"></li>
              <li class="" rel="2"><img src="<?php echo base_url()?>images/logos-by-industry/Dental-Logo-Design/thumbs/2.jpg"></li>
              <li class="" rel="3"><img src="<?php echo base_url()?>images/logos-by-industry/Dental-Logo-Design/thumbs/3.jpg"></li>
              
            </ul>
          </div>
        </div></td>
    </tr>
  </tbody>
</table>
<?php }

		                  		
		         
		                  		
                  			if($value == "Construction Logo Design")
		                  		{ ?>

<table class="" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td colspan="0"><div>
          <div class="bigPic" style="height:255px; width:936px;"> <img src="<?php echo base_url()?>images/logos-by-industry/Construction-Logo-Design/1.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Construction-Logo-Design/2.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Construction-Logo-Design/3.jpg"> </div>
          <div class="thumbs" style="display:block;">
            <ul style="width: 1476px;">
              <li class="" rel="1"><img src="<?php echo base_url()?>images/logos-by-industry/Construction-Logo-Design/thumbs/1.jpg"></li>
              <li class="" rel="2"><img src="<?php echo base_url()?>images/logos-by-industry/Construction-Logo-Design/thumbs/2.jpg"></li>
              <li class="" rel="3"><img src="<?php echo base_url()?>images/logos-by-industry/Construction-Logo-Design/thumbs/3.jpg"></li>
                          </ul>
          </div>
        </div></td>
    </tr>
  </tbody>
</table>
<?php }
		                  		
                  			if($value == "Education Logo Design")
		                  		{ ?>

<table class="" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td colspan="0"><div>
          <div class="bigPic" style="height:255px; width:936px;"> <img src="<?php echo base_url()?>images/logos-by-industry/Education-Logo-Design/1.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Education-Logo-Design/2.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Education-Logo-Design/3.jpg"> </div>
          <div class="thumbs" style="display:block;">
            <ul style="width: 1476px;">
              <li class="" rel="1"><img src="<?php echo base_url()?>images/logos-by-industry/Education-Logo-Design/thumbs/1.jpg"></li>
              <li class="" rel="2"><img src="<?php echo base_url()?>images/logos-by-industry/Education-Logo-Design/thumbs/2.jpg"></li>
              <li class="" rel="3"><img src="<?php echo base_url()?>images/logos-by-industry/Education-Logo-Design/thumbs/3.jpg"></li>
              
            </ul>
          </div>
        </div></td>
    </tr>
  </tbody>
</table>
<?php }




                  			if($value == "Entertainment Logo Design")
		                  		{ ?>

<table class="" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td colspan="0"><div>
          <div class="bigPic" style="height:255px; width:936px;"> <img src="<?php echo base_url()?>images/logos-by-industry/Entertainment-Logo-Design/1.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Entertainment-Logo-Design/2.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Entertainment-Logo-Design/3.jpg"> </div>
          <div class="thumbs" style="display:block;">
            <ul style="width: 1476px;">
              <li class="" rel="1"><img src="<?php echo base_url()?>images/logos-by-industry/Entertainment-Logo-Design/thumbs/1.jpg"></li>
              <li class="" rel="2"><img src="<?php echo base_url()?>images/logos-by-industry/Entertainment-Logo-Design/thumbs/2.jpg"></li>
              <li class="" rel="3"><img src="<?php echo base_url()?>images/logos-by-industry/Entertainment-Logo-Design/thumbs/3.jpg"></li>
              
            </ul>
          </div>
        </div></td>
    </tr>
  </tbody>
</table>
<?php }



                  			if($value == "Event Logo Design")
		                  		{ ?>

<table class="" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td colspan="0"><div>
          <div class="bigPic" style="height:255px; width:936px;"> <img src="<?php echo base_url()?>images/logos-by-industry/Event-Logo-Design/1.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Event-Logo-Design/2.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Event-Logo-Design/3.jpg"> </div>
          <div class="thumbs" style="display:block;">
            <ul style="width: 1476px;">
              <li class="" rel="1"><img src="<?php echo base_url()?>images/logos-by-industry/Event-Logo-Design/thumbs/1.jpg"></li>
              <li class="" rel="2"><img src="<?php echo base_url()?>images/logos-by-industry/Event-Logo-Design/thumbs/2.jpg"></li>
              <li class="" rel="3"><img src="<?php echo base_url()?>images/logos-by-industry/Event-Logo-Design/thumbs/3.jpg"></li>
              
            </ul>
          </div>
        </div></td>
    </tr>
  </tbody>
</table>
<?php }



                  			if($value == "Financial Services Logo Design")
		                  		{ ?>

<table class="" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td colspan="0"><div>
          <div class="bigPic" style="height:255px; width:936px;"> <img src="<?php echo base_url()?>images/logos-by-industry/Financial-Services-Logo-Design/1.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Financial-Services-Logo-Design/2.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Financial-Services-Logo-Design/3.jpg"> </div>
          <div class="thumbs" style="display:block;">
            <ul style="width: 1476px;">
              <li class="" rel="1"><img src="<?php echo base_url()?>images/logos-by-industry/Financial-Services-Logo-Design/thumbs/1.jpg"></li>
              <li class="" rel="2"><img src="<?php echo base_url()?>images/logos-by-industry/Financial-Services-Logo-Design/thumbs/2.jpg"></li>
              <li class="" rel="3"><img src="<?php echo base_url()?>images/logos-by-industry/Financial-Services-Logo-Design/thumbs/3.jpg"></li>
              
            </ul>
          </div>
        </div></td>
    </tr>
  </tbody>
</table>
<?php }



                  			if($value == "Golf Courses Logo Design")
		                  		{ ?>

<table class="" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td colspan="0"><div>
          <div class="bigPic" style="height:255px; width:936px;"> <img src="<?php echo base_url()?>images/logos-by-industry/Golf-Courses-Logo-Design/1.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Golf-Courses-Logo-Design/2.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Golf-Courses-Logo-Design/3.jpg"> </div>
          <div class="thumbs" style="display:block;">
            <ul style="width: 1476px;">
              <li class="" rel="1"><img src="<?php echo base_url()?>images/logos-by-industry/Golf-Courses-Logo-Design/thumbs/1.jpg"></li>
              <li class="" rel="2"><img src="<?php echo base_url()?>images/logos-by-industry/Golf-Courses-Logo-Design/thumbs/2.jpg"></li>
              <li class="" rel="3"><img src="<?php echo base_url()?>images/logos-by-industry/Golf-Courses-Logo-Design/thumbs/3.jpg"></li>
              
            </ul>
          </div>
        </div></td>
    </tr>
  </tbody>
</table>
<?php }


                  			if($value == "High Tech Logo Design")
		                  		{ ?>

<table class="" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td colspan="0"><div>
          <div class="bigPic" style="height:255px; width:936px;"> <img src="<?php echo base_url()?>images/logos-by-industry/High-Tech-Logo-Design/1.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/High-Tech-Logo-Design/2.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/High-Tech-Logo-Design/3.jpg"> </div>
          <div class="thumbs" style="display:block;">
            <ul style="width: 1476px;">
              <li class="" rel="1"><img src="<?php echo base_url()?>images/logos-by-industry/High-Tech-Logo-Design/thumbs/1.jpg"></li>
              <li class="" rel="2"><img src="<?php echo base_url()?>images/logos-by-industry/High-Tech-Logo-Design/thumbs/2.jpg"></li>
              <li class="" rel="3"><img src="<?php echo base_url()?>images/logos-by-industry/High-Tech-Logo-Design/thumbs/3.jpg"></li>
              
            </ul>
          </div>
        </div></td>
    </tr>
  </tbody>
</table>
<?php }
		                  		
		                  		
		                  		if($value == "Illustrative Logo Design")
		                  		{ ?>

<table class="" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td colspan="0"><div>
          <div class="bigPic" style="height:255px; width:936px;"> <img src="<?php echo base_url()?>images/logos-by-industry/Illustrative-Logo-Design/1.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Illustrative-Logo-Design/2.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Illustrative-Logo-Design/3.jpg"> </div>
          <div class="thumbs" style="display:block;">
            <ul style="width: 1476px;">
              <li class="" rel="1"><img src="<?php echo base_url()?>images/logos-by-industry/Illustrative-Logo-Design/thumbs/1.jpg"></li>
              <li class="" rel="2"><img src="<?php echo base_url()?>images/logos-by-industry/Illustrative-Logo-Design/thumbs/2.jpg"></li>
              <li class="" rel="3"><img src="<?php echo base_url()?>images/logos-by-industry/Illustrative-Logo-Design/thumbs/3.jpg"></li>
              
            </ul>
          </div>
        </div></td>
    </tr>
  </tbody>
</table>
<?php }





                  			if($value == "International Logo Design")
		                  		{ ?>

<table class="" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td colspan="0"><div>
          <div class="bigPic" style="height:255px; width:936px;"> <img src="<?php echo base_url()?>images/logos-by-industry/International-Logo-Design/1.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/International-Logo-Design/2.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/International-Logo-Design/3.jpg"> </div>
          <div class="thumbs" style="display:block;">
            <ul style="width: 1476px;">
              <li class="" rel="1"><img src="<?php echo base_url()?>images/logos-by-industry/International-Logo-Design/thumbs/1.jpg"></li>
              <li class="" rel="2"><img src="<?php echo base_url()?>images/logos-by-industry/International-Logo-Design/thumbs/2.jpg"></li>
              <li class="" rel="3"><img src="<?php echo base_url()?>images/logos-by-industry/International-Logo-Design/thumbs/3.jpg"></li>
              
            </ul>
          </div>
        </div></td>
    </tr>
  </tbody>
</table>
<?php }




                  			if($value == "Internet Logo Design")
		                  		{ ?>

<table class="" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td colspan="0"><div>
          <div class="bigPic" style="height:255px; width:936px;"> <img src="<?php echo base_url()?>images/logos-by-industry/Internet-Logo-Design/1.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Internet-Logo-Design/2.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Internet-Logo-Design/3.jpg"> </div>
          <div class="thumbs" style="display:block;">
            <ul style="width: 1476px;">
              <li class="" rel="1"><img src="<?php echo base_url()?>images/logos-by-industry/Internet-Logo-Design/thumbs/1.jpg"></li>
              <li class="" rel="2"><img src="<?php echo base_url()?>images/logos-by-industry/Internet-Logo-Design/thumbs/2.jpg"></li>
              <li class="" rel="3"><img src="<?php echo base_url()?>images/logos-by-industry/Internet-Logo-Design/thumbs/3.jpg"></li>
              
            </ul>
          </div>
        </div></td>
    </tr>
  </tbody>
</table>
<?php }


                  			if($value == "Landscaping Logo Design")
		                  		{ ?>

<table class="" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td colspan="0"><div>
          <div class="bigPic" style="height:255px; width:936px;"> <img src="<?php echo base_url()?>images/logos-by-industry/Landscaping-Logo-Design/1.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Landscaping-Logo-Design/2.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Landscaping-Logo-Design/3.jpg"> </div>
          <div class="thumbs" style="display:block;">
            <ul style="width: 1476px;">
              <li class="" rel="1"><img src="<?php echo base_url()?>images/logos-by-industry/Landscaping-Logo-Design/thumbs/1.jpg"></li>
              <li class="" rel="2"><img src="<?php echo base_url()?>images/logos-by-industry/Landscaping-Logo-Design/thumbs/2.jpg"></li>
              <li class="" rel="3"><img src="<?php echo base_url()?>images/logos-by-industry/Landscaping-Logo-Design/thumbs/3.jpg"></li>
              
            </ul>
          </div>
        </div></td>
    </tr>
  </tbody>
</table>
<?php }



		                  			if($value == "Medical Logo Design")
		                  		{ ?>
<table class="" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td colspan="0"><div>
          <div class="bigPic" style="height:255px; width:936px;"> <img src="<?php echo base_url()?>images/logos-by-industry/Medical-Logo-Design/1.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Medical-Logo-Design/2.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Medical-Logo-Design/3.jpg"> </div>
          <div class="thumbs" style="display:block;">
            <ul style="width: 1476px;">
              <li class="" rel="1"><img src="<?php echo base_url()?>images/logos-by-industry/Medical-Logo-Design/thumbs/1.jpg"></li>
              <li class="" rel="2"><img src="<?php echo base_url()?>images/logos-by-industry/Medical-Logo-Design/thumbs/2.jpg"></li>
              <li class="" rel="3"><img src="<?php echo base_url()?>images/logos-by-industry/Medical-Logo-Design/thumbs/3.jpg"></li>
              
            </ul>
          </div>
        </div></td>
    </tr>
  </tbody>
</table>
<?php }


                  			
		                  			if($value == "Networking Logo Design")
		                  		{ ?>
<table class="" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td colspan="0"><div>
          <div class="bigPic" style="height:255px; width:936px;"> <img src="<?php echo base_url()?>images/logos-by-industry/Networking-Logo-Design/1.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Networking-Logo-Design/2.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Networking-Logo-Design/3.jpg"> </div>
          <div class="thumbs" style="display:block;">
            <ul style="width: 1476px;">
              <li class="" rel="1"><img src="<?php echo base_url()?>images/logos-by-industry/Networking-Logo-Design/thumbs/1.jpg"></li>
              <li class="" rel="2"><img src="<?php echo base_url()?>images/logos-by-industry/Networking-Logo-Design/thumbs/2.jpg"></li>
              <li class="" rel="3"><img src="<?php echo base_url()?>images/logos-by-industry/Networking-Logo-Design/thumbs/3.jpg"></li>
              
            </ul>
          </div>
        </div></td>
    </tr>
  </tbody>
</table>
<?php }


                  			if($value == "Pool and Spa Logo Design")
		                  		{ ?>
<table class="" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td colspan="0"><div>
          <div class="bigPic" style="height:255px; width:936px;"> <img src="<?php echo base_url()?>images/logos-by-industry/Pool-and-Spa-Logo-Design/1.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Pool-and-Spa-Logo-Design/2.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Pool-and-Spa-Logo-Design/3.jpg"> </div>
          <div class="thumbs" style="display:block;">
            <ul style="width: 1476px;">
              <li class="" rel="1"><img src="<?php echo base_url()?>images/logos-by-industry/Pool-and-Spa-Logo-Design/thumbs/1.jpg"></li>
              <li class="" rel="2"><img src="<?php echo base_url()?>images/logos-by-industry/Pool-and-Spa-Logo-Design/thumbs/2.jpg"></li>
              <li class="" rel="3"><img src="<?php echo base_url()?>images/logos-by-industry/Pool-and-Spa-Logo-Design/thumbs/3.jpg"></li>
              
            </ul>
          </div>
        </div></td>
    </tr>
  </tbody>
</table>
<?php }




                  			if($value == "Real Estate Development Logo Design")
		                  		{ ?>

<table class="" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td colspan="0"><div>
          <div class="bigPic" style="height:255px; width:936px;"> <img src="<?php echo base_url()?>images/logos-by-industry/Real-Estate-Development-Logo-Design/1.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Real-Estate-Development-Logo-Design/2.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Real-Estate-Development-Logo-Design/3.jpg"> </div>
          <div class="thumbs" style="display:block;">
            <ul style="width: 1476px;">
              <li class="" rel="1"><img src="<?php echo base_url()?>images/logos-by-industry/Real-Estate-Development-Logo-Design/thumbs/1.jpg"></li>
              <li class="" rel="2"><img src="<?php echo base_url()?>images/logos-by-industry/Real-Estate-Development-Logo-Design/thumbs/2.jpg"></li>
              <li class="" rel="3"><img src="<?php echo base_url()?>images/logos-by-industry/Real-Estate-Development-Logo-Design/thumbs/3.jpg"></li>
              
            </ul>
          </div>
        </div></td>
    </tr>
  </tbody>
</table>
<?php }


                  			if($value == "Realtor Logo Design")
		                  		{ ?>

<table class="" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td colspan="0"><div>
          <div class="bigPic" style="height:255px; width:936px;"> <img src="<?php echo base_url()?>images/logos-by-industry/Realtor-Logo-Design/1.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Realtor-Logo-Design/2.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Realtor-Logo-Design/3.jpg"> </div>
          <div class="thumbs" style="display:block;">
            <ul style="width: 1476px;">
              <li class="" rel="1"><img src="<?php echo base_url()?>images/logos-by-industry/Realtor-Logo-Design/thumbs/1.jpg"></li>
              <li class="" rel="2"><img src="<?php echo base_url()?>images/logos-by-industry/Realtor-Logo-Design/thumbs/2.jpg"></li>
              <li class="" rel="3"><img src="<?php echo base_url()?>images/logos-by-industry/Realtor-Logo-Design/thumbs/3.jpg"></li>
              
            </ul>
          </div>
        </div></td>
    </tr>
  </tbody>
</table>
<?php }




                  			
                  			if($value == "Restaurant Logo Design")
		                  		{ ?>

<table class="" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td colspan="0"><div>
          <div class="bigPic" style="height:255px; width:936px;"> <img src="<?php echo base_url()?>images/logos-by-industry/Restaurant-Logo-Design/1.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Restaurant-Logo-Design/2.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Restaurant-Logo-Design/3.jpg"> </div>
          <div class="thumbs" style="display:block;">
            <ul style="width: 1476px;">
              <li class="" rel="1"><img src="<?php echo base_url()?>images/logos-by-industry/Restaurant-Logo-Design/thumbs/1.jpg"></li>
              <li class="" rel="2"><img src="<?php echo base_url()?>images/logos-by-industry/Restaurant-Logo-Design/thumbs/2.jpg"></li>
              <li class="" rel="3"><img src="<?php echo base_url()?>images/logos-by-industry/Restaurant-Logo-Design/thumbs/3.jpg"></li>
              
            </ul>
          </div>
        </div></td>
    </tr>
  </tbody>
</table>
<?php }
		                  		
		                  		
		                  		 
		                  		if($value == "Retail Logo Design")
		                  		{ ?>

<table class="" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td colspan="0"><div>
          <div class="bigPic" style="height:255px; width:936px;"> <img src="<?php echo base_url()?>images/logos-by-industry/Retail-Logo-Design/1.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Retail-Logo-Design/2.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Retail-Logo-Design/3.jpg"> </div>
          <div class="thumbs" style="display:block;">
            <ul style="width: 1476px;">
              <li class="" rel="1"><img src="<?php echo base_url()?>images/logos-by-industry/Retail-Logo-Design/thumbs/1.jpg"></li>
              <li class="" rel="2"><img src="<?php echo base_url()?>images/logos-by-industry/Retail-Logo-Design/thumbs/2.jpg"></li>
              <li class="" rel="3"><img src="<?php echo base_url()?>images/logos-by-industry/Retail-Logo-Design/thumbs/3.jpg"></li>
              
            </ul>
          </div>
        </div></td>
    </tr>
  </tbody>
</table>
<?php }

                  			if($value == "Salon Day Spa Logo Design")
		                  		{ ?>

<table class="" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td colspan="0"><div>
          <div class="bigPic" style="height:255px; width:936px;"> <img src="<?php echo base_url()?>images/logos-by-industry/Salon-Day-Spa-Logo-Design/1.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Salon-Day-Spa-Logo-Design/2.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Salon-Day-Spa-Logo-Design/3.jpg"> </div>
          <div class="thumbs" style="display:block;">
            <ul style="width: 1476px;">
              <li class="" rel="1"><img src="<?php echo base_url()?>images/logos-by-industry/Salon-Day-Spa-Logo-Design/thumbs/1.jpg"></li>
              <li class="" rel="2"><img src="<?php echo base_url()?>images/logos-by-industry/Salon-Day-Spa-Logo-Design/thumbs/2.jpg"></li>
              <li class="" rel="3"><img src="<?php echo base_url()?>images/logos-by-industry/Salon-Day-Spa-Logo-Design/thumbs/3.jpg"></li>
              
            </ul>
          </div>
        </div></td>
    </tr>
  </tbody>
</table>
<?php }



	                      		
                  			if($value == "Service Industries Logo Design")
		                  		{ ?>
<table class="" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td colspan="0"><div>
          <div class="bigPic" style="height:255px; width:936px;"> <img src="<?php echo base_url()?>images/logos-by-industry/Service-Industries-Logo-Design/1.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Service-Industries-Logo-Design/2.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Service-Industries-Logo-Design/3.jpg"> </div>
          <div class="thumbs" style="display:block;">
            <ul style="width: 1476px;">
              <li class="" rel="1"><img src="<?php echo base_url()?>images/logos-by-industry/Service-Industries-Logo-Design/thumbs/1.jpg"></li>
              <li class="" rel="2"><img src="<?php echo base_url()?>images/logos-by-industry/Service-Industries-Logo-Design/thumbs/2.jpg"></li>
              <li class="" rel="3"><img src="<?php echo base_url()?>images/logos-by-industry/Service-Industries-Logo-Design/thumbs/3.jpg"></li>
              
            </ul>
          </div>
        </div></td>
    </tr>
  </tbody>
</table>
<?php }



                  			if($value == "Travel Logo Design")
		                  		{ ?>
<table class="" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td colspan="0"><div>
          <div class="bigPic" style="height:255px; width:936px;"> <img src="<?php echo base_url()?>images/logos-by-industry/Travel-Logo-Design/1.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Travel-Logo-Design/2.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Travel-Logo-Design/3.jpg"> </div>
          <div class="thumbs" style="display:block;">
            <ul style="width: 1476px;">
              <li class="" rel="1"><img src="<?php echo base_url()?>images/logos-by-industry/Travel-Logo-Design/thumbs/1.jpg"></li>
              <li class="" rel="2"><img src="<?php echo base_url()?>images/logos-by-industry/Travel-Logo-Design/thumbs/2.jpg"></li>
              <li class="" rel="3"><img src="<?php echo base_url()?>images/logos-by-industry/Travel-Logo-Design/thumbs/3.jpg"></li>
              
            </ul>
          </div>
        </div></td>
    </tr>
  </tbody>
</table>
<?php }




if($value == "Off The Wall Logo Design")
		                  		{ ?>

<table class="" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td colspan="0"><div>
          <div class="bigPic" style="height:255px; width:936px;"> <img src="<?php echo base_url()?>images/logos-by-industry/Off-The-Wall-Logo-Design/1.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Off-The-Wall-Logo-Design/2.jpg"> <img  src="<?php echo base_url()?>images/logos-by-industry/Off-The-Wall-Logo-Design/3.jpg"> </div>
          <div class="thumbs" style="display:block;">
            <ul style="width: 1476px;">
              <li class="" rel="1"><img src="<?php echo base_url()?>images/logos-by-industry/Off-The-Wall-Logo-Design/thumbs/1.jpg"></li>
              <li class="" rel="2"><img src="<?php echo base_url()?>images/logos-by-industry/Off-The-Wall-Logo-Design/thumbs/2.jpg"></li>
              <li class="" rel="3"><img src="<?php echo base_url()?>images/logos-by-industry/Off-The-Wall-Logo-Design/thumbs/3.jpg"></li>
              
            </ul>
          </div>
        </div></td>
    </tr>
  </tbody>
</table>
<?php }

                  			
                  			
                  			}?>

<!-- jQuery Effect Scripts --> 
<script type="text/javascript">
	var currImage;
	var currIndex = -1;
	var interval = 2500;
	var myTimer;
	
	jQuery(document).ready(function() {
		myTimer = setTimeout("showNext()", interval);
		showNext(); //loads first image
		jQuery('.thumbs ul li').bind('click',function(e){
			var count = jQuery(this).attr('rel');
			showImage(parseInt(count)-1);
		});
		
		var ul = jQuery('.thumbs ul');
		
		//console.log('wid  ml mr pl pr bl br');
		ul.width( widthByChild(ul) );
		//alert(widthByChild(ul));
		
		//ul.css('width',widthByChild(ul)+'px');
	});
	
	function showImage(index){
		if(index < jQuery('.bigPic img').length){
			var indexImage = jQuery('.bigPic img')[index];
			if(currImage){   
				if(currImage != indexImage ){
					jQuery(currImage).css('z-index',2);
					clearTimeout(myTimer);
					jQuery(currImage).fadeOut(1500, function() {
						myTimer = setTimeout("showNext()", interval);
						jQuery(this).css({'display':'none','z-index':1})
					});
				}
			}
			jQuery(indexImage).css({'display':'block', 'opacity':1});
			currImage = indexImage;
			currIndex = index;
			jQuery('.thumbs ul li').removeClass('active');
			jQuery(jQuery('.thumbs ul li')[index]).addClass('active');
		}
	}
	
	function showNext(){
		var len = jQuery('.bigPic img').length;
		var next = currIndex < (len-1) ? currIndex + 1 : 0;
		showImage(next);
	}
	
	function widthByChild(obj){
	
		var total = 0;
		var children = obj.children();
		jQuery.each(children, function(){
			var item = jQuery(this);
		
			var blw = parseInt(item.css('border-left-width'));
			var brw = parseInt(item.css('border-right-width'));
			var addition = 0;
			
			if ( blw < 5 && blw > 0 ){
				//item.css('border-left-width','5px');
				addition+=2;
			}
			if ( brw < 5 && brw > 0 ){
				//item.css('border-right-width','5px');
				addition+=2;
			}
			
			
			
			total += parseInt(item.css('width'))
				+ parseInt(item.css('margin-left'))
				+ parseInt(item.css('margin-right'))
				+ parseInt(item.css('padding-left'))
				+ parseInt(item.css('padding-right'))
				+ parseInt(item.css('border-left-width'))
				+ parseInt(item.css('border-right-width'))
				+ addition + 3;
		});
		
		return total;
	}
	</script>