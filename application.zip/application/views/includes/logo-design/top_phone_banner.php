<div class="banner">
<p>Call "free" a design expert 24/7:<br />
   <span><?= PHONE_NO; ?></span></p>
</div>