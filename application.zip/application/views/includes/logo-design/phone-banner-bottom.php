<div class="phone-banner-bottom"> 
    <p>Call us TOLL FREE<br />
  <span><?= PHONE_NO; ?></span></p> 
</div>