<div class="partners">
<span>
        <span>  
        
            <div>
                <a href="javascript:void(0)"><img src="<?= base_url().'assets/images/partners/business.jpg'?>" alt="Business.com" title="business.com" /></a>
                <a href="javascript:void(0)"><img src="<?= base_url().'assets/images/partners/microsoft.jpg'?>" alt="Microsoft Gold Certified" title="Microsoft Gold Certified" /></a>
                <a href="javascript:void(0)"><img src="<?= base_url().'assets/images/partners/paypal.jpg'?>" alt="Paypal" title="Paypal" /></a>
                <a href="javascript:void(0)"><img src="<?= base_url().'assets/images/partners/tech.jpg'?>" alt="tech" title="tech" /></a>
            </div>
            <div>  
                <a href="javascript:void(0)"><img src="<?= base_url().'assets/images/partners/fsb.jpg'?>" alt="fsb" title="fsb" /></a>
                <a href="javascript:void(0)"><img src="<?= base_url().'assets/images/partners/cardsave.jpg'?>" alt="card save" title="card save" /></a>
                <a href="javascript:void(0)"><img src="<?= base_url().'assets/images/partners/dNb.jpg'?>" alt="D and B" title="D and B" /></a>
                <a href="javascript:void(0)"><img src="<?= base_url().'assets/images/partners/iso.jpg'?>" alt="ISO" title="ISO" /></a>
                <!--<a href="javascript:void(0)"><img src="<?= base_url().'assets/images/partners/w3c.jpg'?>" alt="W3C" title="W3C" /></a>-->
                <a href="javascript:void(0)"><img src="<?= base_url().'assets/images/partners/nasscom.jpg'?>" alt="NASSCOM" title="NASSCOM" /></a>
                <a href="javascript:void(0)"><img src="<?= base_url().'assets/images/partners/worldpay.jpg'?>" alt="World Pay" title="World Pay" /></a>
                <!--<a href="javascript:void(0)"><img src="<?= base_url().'assets/images/partners/securetrading.jpg'?>" alt="Secure Trading" title="Secure Trading" /></a> -->
            </div>
            <div>
                <a href="javascript:void(0)"><img src="<?= base_url().'assets/images/partners/google.jpg'?>" alt="google.com" title="google.com" /></a>
                <a href="javascript:void(0)"><img src="<?= base_url().'assets/images/partners/yahoo.jpg'?>" alt="yahoo.com" title="yahoo.com" /></a>
                <a href="javascript:void(0)"><img src="<?= base_url().'assets/images/partners/ukwda.jpg'?>" alt="ukwda" title="ukwda" /></a>
                <a href="javascript:void(0)"><img src="<?= base_url().'assets/images/partners/amazon.jpg'?>" alt="amazon" title="amazon" /></a>
                <a href="javascript:void(0)"><img src="<?= base_url().'assets/images/partners/paypal2.jpg'?>" alt="paypal" title="paypal" /></a>
                <a href="javascript:void(0)"><img src="<?= base_url().'assets/images/partners/microsoft_net.jpg'?>" alt="microsoft.net" title="microsoft.net" /></a>
                <a href="javascript:void(0)"><img src="<?= base_url().'assets/images/partners/bing.jpg'?>" alt="bing.com" title="bing.com" /></a>
                <a href="javascript:void(0)"><img src="<?= base_url().'assets/images/partners/ebay.jpg'?>" alt="ebay.com" title="ebay.com" /></a>
                <a href="javascript:void(0)"><img src="<?= base_url().'assets/images/partners/sage_pay.jpg'?>" alt="Sage Pay" title="Sage Pay" /></a>
            </div> 
         
        </span>
        
    </span>
</div>