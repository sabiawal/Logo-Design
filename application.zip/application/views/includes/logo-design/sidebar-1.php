<div class="money-back">
    <div><img src="<?php echo base_url()?>images/side-bar-bg-top.jpg" title="bg-top" /></div>
    <div class="money-back-text">
    <div align="center"><a href="<?php echo site_url('guarantee'); ?>"><img src="<?php echo base_url()?>images/guarantee.png" alt="Money Back Guarantee" title="Money Back Guarantee" /></a></div>
        <ul>
        <li>100 % original, custom-made</li>
        <li>No clipart </li>
        <?php if($this->router->method == 'packages'){ echo "<li>24/7 ".COUNTRY." Phone Support</li>";} ?>
        </ul>
    <?php if($this->router->method != 'packages'){  ?>
    <div align="center"><a href="<?php echo site_url('packages');?>"><img src="<?php echo base_url()?>images/start-logo.jpg" alt="Start My Logo" title="Start My Logo" /></a></div>
    <?php } ?>
    </div>
    <div><img src="<?php echo base_url()?>images/side-bar-bg-bottom.jpg" title="bg-top" /></div>
</div>

<div class="live-support">
<div><img src="<?php echo base_url()?>images/side-bar-bg-top.jpg" title="bg-top" /></div>
<div class="live-support-text" align="center">
<div align="center" style="margin:0 0 10px 0;">
<!-- BEGIN ProvideSupport.com Graphics Chat Button Code -->
<div id="ciz1K7" style="z-index:100;position:absolute"></div>
<div id="scz1K7" style="display:inline; text-align:center;"> </div>
<div id="sdz1K7" style="display:none; text-align:center;"></div>
<script type="text/javascript">var sez1K7=document.createElement("script");sez1K7.type="text/javascript";sez1K7.defer=true;sez1K7.src=(location.protocol.indexOf("https")==0?"https://secure.providesupport.com/image":"http://image.providesupport.com")+"/js/pradyumna/safe-standard.js?ps_h=z1K7\u0026ps_t="+new Date().getTime();document.getElementById("sdz1K7").appendChild(sez1K7)</script>
<noscript>
<div style="display:inline; text-align:center">
<div style="text-align:center">
<a href="http://www.providesupport.com?messenger=pradyumna">Live Support</a></div>
</div></noscript>
<!-- END ProvideSupport.com Graphics Chat Button Code -->
</div>
<p>Our staff are here to help you now. Click the box above for immediate answers to your queries.</p>
</div>
<div><img src="<?php echo base_url()?>images/side-bar-bg-bottom.jpg" title="bg-top" /></div>
</div>

<div class="charity">
<div><img src="<?php echo base_url()?>images/side-bar-bg-top.jpg" title="bg-top" /></div>
<div class="charity-text">
<h1>See our charitable works </h1>
<div align="center"><a href="<?php echo site_url('charity'); ?>"><img src="<?php echo base_url()?>images/rtdthumb.jpg" alt="RTD" title="RTD" /></a></div><p>&nbsp;</p>
<p>Logo Design Guarantee has designed many logos for leading charities. See some of our logos we have designed for Churches.<br/>
<a href="<?php echo site_url('charity')?>"  style="color:#666;"><span class="text-bold"> Read more.</span></a></p>
</div>
<div><img src="<?php echo base_url()?>images/side-bar-bg-bottom.jpg" title="bg-top" /></div>
</div>