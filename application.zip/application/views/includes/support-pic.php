<div class="col-md-3 support-pic">
	<div class="pic">
		<img class="img-responsive" src="assets/images/devoted-support-pic.png" alt="support pic" />
	</div>
	<ul>
		<li><img style="margin: 0 16px 0 0;" src="assets/images/telephone-sign.png" alt="telephone" /><?php echo PHONE_NO; ?></li>
		<li><a class="chat-service" href="javascript:void(0);"><img src="assets/images/hi-bubble-gray.png" alt="hi" /> Click to Chat</a></li>
	</ul>
</div>