<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Upgrade</title>
</head>

<body style="padding:20px 0; background:#eaeaea; margin:0;">
<table align="center" border="0" cellpadding="0" bgcolor="#ffffff" cellspacing="0" width="600" style="border-collapse:collapse; padding:25px 0; background-color:#ffffff; font:0.75em Gotham, 'Helvetica Neue', Helvetica, Arial, sans-serif; box-shadow: 0 0 5px 1px #999999;
margin:0 auto;">
   <tr>
  	<td valign="top" style="background: #FFD700 !important;
    color:#FFFFFF;
    font-size: 26px;
    font-weight: 700;
    height: 60px;
    line-height: 2.3;
    font-family:Arial, Helvetica, sans-serif;
    font-weight:bold !important;
    margin: 0;
    text-align: center !important;
    text-shadow: 1px -1px 1px rgba(0, 0, 0, 0.5);
    text-transform: uppercase;
    "><span>ELITE LOGO WITH BUSINESS CARD DESIGNS</span></td>
  </tr>  
  <tr>
  <td valign="top" style="padding:0px 20px;" >
  <table><tr>
  	<td valign="top" style="  font-size: 25px;    
    font-family:Arial, Helvetica, sans-serif;
    font-weight:normal !important;
    margin-top: 10px;
    padding: 0 23px; float:left; color:#666666; background:#F0F0F0;width:390px;
    height:38px;" >
    <span style="line-height:1.2;" >12 custom made logos</span>
    </td>
    <td style="background-color: #CACACA;
    font-family: arial;
    font-size: 33px;
    line-height: 1.2;
    margin-top: 10px;
    color: #000000 !important;
    float: left;  font-size: 25px;
    line-height: 1.5;
    font-family:Arial, Helvetica, sans-serif;
    font-weight:normal !important;
    font-style:normal !important;
    padding: 0 23px;
    ">
    <span ><?php echo CURRENCY.$_SESSION['upgraded_packages_amount']?></span>
    </td>
    </tr>
 </table>
 </td>
  </tr>
  
  <tr>
  	<td valign="top" style="padding:0px 20px;" >
    
    <p style=" font: 15px/24px Tahoma,Geneva,sans-serif;
    margin: 10px 0 20px;
    color: #666666;">The Elite Logo Design Package truly provides a comprehensive logo design service. This package has been specifically created from client feedback. Everything an organization needs for complete peace of mind on design variations.</p>
    </td>
 
  </tr>
  
    <tr>
  	<td valign="top" style="padding:0px 20px;" >
    
  <ul style=" list-style:none; list-style-position:outside; padding:0; margin:0">
  <li style="  font: bold 17px/24px Tahoma,Geneva,sans-serif;
    margin: 0 0 20px; color:#666666;"><span style="color:#BCA000">Free </span> Complete logo design research.</li>
 <li style="  font: bold 17px/24px Tahoma,Geneva,sans-serif;
    margin: 0 0 20px; color:#666666;"><span style="color:#BCA000">6 designers </span>to share and contribute ideas.</li>
 <li style="  font: bold 17px/24px Tahoma,Geneva,sans-serif;
    margin: 0 0 20px; color:#666666;"><span style="color:#BCA000">Dedicated </span>project manager!.</li>
 <li style="  font: bold 17px/24px Tahoma,Geneva,sans-serif;
    margin: 0 0 20px; color:#BCA000">12 custom-made logo samples.</li>
 <li style="  font: bold 17px/24px Tahoma,Geneva,sans-serif;
    margin: 0 0 20px; color:#666666;">Professional design - No templates - No clipart used.,</li>
 <li style="  font: bold 17px/24px Tahoma,Geneva,sans-serif;
    margin: 0 0 20px; color:#666666;"> Each logo sample is 100% original, unique and different.</li>
 <li style="  font: bold 17px/24px Tahoma,Geneva,sans-serif;
    margin: 0 0 20px; color:#666666;"><span style="color:#BCA000">Unlimited </span>redraws</li>
 <li style="  font: bold 17px/24px Tahoma,Geneva,sans-serif;
    margin: 0 0 20px; color:#666666;"><span style="color:#BCA000">Unlimited </span>concepts</li>
 <li style="  font: bold 17px/24px Tahoma,Geneva,sans-serif;
    margin: 0 0 20px; color:#666666;"><span style="color:#BCA000">Unlimited </span>revisions</li>
 <li style="  font: bold 17px/24px Tahoma,Geneva,sans-serif;
    margin: 0 0 20px; color:#666666;">1- 3 business days turn around on all our logo designs</li>
 <li style="  font: bold 17px/24px Tahoma,Geneva,sans-serif;
    margin: 0 0 20px; color:#666666;"><span style="color:#BCA000">Free</span> Final logo files sent via email - includes formats for all print and web use.</li>
 <li style="  font: bold 17px/24px Tahoma,Geneva,sans-serif;
    margin: 0 0 20px; color:#666666;"><span style="color:#BCA000">Free</span> of charge for any additional files you request</li>
 <li style="  font: bold 17px/24px Tahoma,Geneva,sans-serif;
    margin: 0 0 20px; color:#666666;"><span style="color:#BCA000">Free</span> complete ownership to all the logo design samples we design for you.</li>
 <li style="  font: bold 17px/24px Tahoma,Geneva,sans-serif;
    margin: 0 0 20px; color:#666666;"><span style="color:#BCA000">Free</span> assistance with any print company.</li>
 <li style="  font: bold 17px/24px Tahoma,Geneva,sans-serif;
    margin: 0 0 20px; color:#666666;"><span style="color:#BCA000">Free</span> file designs that allow resize with no distortion (suitable for professional print).</li>
 <li style="  font: bold 17px/24px Tahoma,Geneva,sans-serif;
    margin: 0 0 20px; color:#666666;">3 minute simple online order form!</li>
 <li style="  font: bold 17px/24px Tahoma,Geneva,sans-serif;
    margin: 0 0 20px; color:#666666;">We start your designs today!</li>
 <li style="  font: bold 17px/24px Tahoma,Geneva,sans-serif;
    margin: 0 0 20px; color:#666666;">100% satisfaction Guaranteed</li>
 <li style="  font: bold 17px/24px Tahoma,Geneva,sans-serif;
    margin: 0 0 20px; color:#666666;"><span style="color:#BCA000">Free</span> After-sales support (for life!)</li>
  </ul>
    </td>
 
  </tr>

   <tr>
  	<td valign="top" style="padding:0px 20px;" >
    
    <p style=" font: 15px/24px Tahoma,Geneva,sans-serif;
    margin: 10px 0 20px;
    color: #666666;"><span style="color:#BCA000"><strong>365 -Day - 100% No-Risk Money Back Guarantee.</span> No fees, no questions. Immediate refund. Don't be fooled...we refund at any stage of the design process. Our competitors do not!
(By far the best guarantee in the industry)</strong></p>
    </td>
 
  </tr>
 
 
 

	
	
</table>
</body>
</html>
