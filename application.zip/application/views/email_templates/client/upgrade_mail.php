<!--<link href="<?php echo base_url()?>css_client/import.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="<?php echo base_url()?>css/newmodify.css" />
<style>
.main {
	height:auto !important;
}
</style>-->

<?php 
echo "
<div class='elite-text1' align='left'> <div class='elite-price'>
<span class='old-price'>12 custom made logos</span>

<span class='new-elite-price'>".CURRENCY."69</span>
</div>
<p>The Elite Logo Design Package truly provides a comprehensive logo design service. This package has been specifically created from client feedback. Everything an organization needs for complete peace of mind on design variations.</p>
<ul>
<li><span class='text-elite'>Free</span> Complete logo design research.</li>
<li><span class='text-elite text-18'>6 designers</span> to share and contribute ideas. </li>
<li><span class='text-elite'>Dedicated</span> project manager!.</li>
<li><span class='text-elite'><span class='text-18'>12 custom-made</span> logo samples.</span></li>
<li>Professional design - No templates - No clipart used.</li>
<li>Each logo sample is 100% original, unique and different.</li>
<li><span class='text-elite'>Unlimited </span>redraws</li>
<li><span class='text-elite'>Unlimited </span>concepts</li>
<li><span class='text-elite'>Unlimited </span>revisions</li>
<li>1- 3 business days turn around on all our logo designs</li>
<li><span class='text-elite'>Free</span> Final logo files sent via email - includes formats for all print and web use.</li>
<li><span class='text-elite'>Free</span> of charge for any additional files you request</li>
<li><span class='text-elite'>Free</span> complete ownership to all the logo design samples we design for you.</li>
<li><span class='text-elite'>Free</span> assistance with any print company.</li>
<li><span class='text-elite'>Free</span> file designs that allow resize with no distortion (suitable for professional print).</li>
<li>3 minute simple online order form!</li>
<li>We get your designs started today!</li>
<li>100% satisfaction Guaranteed</li>
<li><span class='text-elite'>Free</span> After-sales support (for life!)</li>
</ul>
<p><strong><span class='text-elite'>
365                  -Day - 100% No-Risk Money Back Guarantee.</span> No fees, no questions. Immediate refund. Don't be fooled...we refund at any stage of the design process. Our competitors do not!<br>
(By far the best guarantee in the industry)</strong></p>
</div>  
";
?>

