<?php $this->load->view('includes/reseller_web/header-common'); ?>
		<section id="order-process" class="content gray-bottom-border">
			<section class="slogan">
				<div class="container">
					<h1 class="text-center theme-green">
						Congratulations!
						<br />
						Your order was successful.
						<br />
						Thank you for your order.
					</h1>
				</div>
			</section>
		</section>
		<div class="normal-desc-box text-center">
			<a href="<?php echo base_url() ?>" class="green-btn order-back-btn">
				<span data-hover="Return to home page">Return to home page</span>
			</a>
		</div>
<?php $this->load->view('includes/reseller_web/footer-common'); ?>