<?php

    ini_set('session.gc_probability','100');   		
	include_once("jetpay/gatewayapi/inc_gatewaysettings.php");
	$amount = @$_SESSION['amount'];
?>
<html>
<head>
<title><? print $mer_name ?>- Transaction Declined</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body bgcolor="#FFFFFF" text="#333333" link="#333333" vlink="#666666" alink="#333333" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<br />
<table width="580" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#003366">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><table width="580" border="0" align="center" cellpadding="5" cellspacing="0">
        <tr bgcolor="#F5F5F5" class="text">
          <td><p align="center">&nbsp;</p></td>
        </tr>
        <tr bgcolor="#FFFFFF" class="text">
          <td><table width="100%" border="0" cellpadding="13" cellspacing="0">
              <tr>
                <td><p class="text">We're Sorry, we can not process your transaction at this time for the following reason: <br />
                    <br />
                    <font color="ff0000"><?php echo $_REQUEST['gateway_error']; ?></font> <br />					
                    <br />
                    Please <a href="javascript:history.go(-1)">click here</a> to submit your transaction again. <span class="text"><br />
                    </span> </p></td>
              </tr>
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td><div align="center"><font size="1">We really appreciate your business <em><? print $mer_name; ?></em>.</font></div></td>
              </tr>
              <tr>
                <td><div align="right"></div></td>
              </tr>
            </table></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>
