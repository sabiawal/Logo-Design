<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN""http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>***Merchatn Name*** - Card Verification Number Examples </title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link type="image/x-icon" href="<?= base_url().'favicon.ico?rand='.rand(); ?>" rel="icon" />
<link type="image/x-icon" href="<?= base_url().'favicon.ico?rand='.rand(); ?>" rel="shortcut icon" />
</head>
<body>
<img alt="Credit Cards - MerchantPlus.com" src="<?= base_url(); ?>assets/images/cv_card.jpg" width="569" height="223" border='1' />
</body>
</html>
