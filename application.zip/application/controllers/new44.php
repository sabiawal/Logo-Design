<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class New44 extends CI_Controller {	
    public function __construct()
    {
        parent::__construct();
        // Your own constructor code
        $this->load->database();
        $this->load->model('new44model');
        
        $day=date("l");$date=date("j");$month=date("M");$year=date("y");
        $today = 'Midnight '.TIME_ZONE.', <span style="text-decoration:underline;">'.$day.'</span> '.$date.' '.$month.' &lsquo;'.$year;        
        $data['today']      = $today;
        $this->load->vars($data);
        $this->output->cache(1440); // 1440 min( one day) 
    }
	public function index(){}
    
    /*public function newpackages()
    {  
        $row = $this->logodesignmodel->get_num_rows('new_packages');    
        
        if(isset($_GET['pid']))
        {
            $num = intval($_GET['pid']);            
            if($num <= 0 || $num > $row)
            {               
                $package_id = 0;
            }
            else
            {
                if($num == 45 || $num == 46)
                {
                    $package_id = 0;
                }
                else
                {
                    $package_id = $num;
                }
                
            }            
        }
        else
        {
            $package_id = 0;
        }  
        //echo $package_id;      
        
        if ($package_id != 0)
		{
			$packages['new_package'] = $this->logodesignmodel->getpackages($package_id);        
			$this->load->view('new44/newpackages',$packages);
		}		
	}
    
    public function category(){
        $data['marketing_package']  = $this->logodesignmodel->get_more_services(1); 
        $data['logo_package']       = $this->logodesignmodel->get_more_services(2); 
        $data['email_package']      = $this->logodesignmodel->get_more_services(3);
        $data['web_package']        = $this->logodesignmodel->get_more_services(4);  
        $data['merc_package']       = $this->logodesignmodel->get_more_services(5); 
        $data['stationary_package'] = $this->logodesignmodel->get_more_services(6);        
        $data['page_title'] = 'More Services';
        $this->load->view('new44/category',$data);
	}*/
    public function category(){
        redirect('new44/more_services');
    }
    public function more_services(){              
        $data['page_title'] = 'More Services';
        $this->load->view('new44/more_services',$data);
	}
    
    public function email_newsletter(){
        $data['package_detail'] = $this->new44model->get_more_services(3,22); // category_id, package_id
        
        $this->load->view('new44/email_newsletter',$data);
    }
    public function email_signature(){
        $data['package_detail'] = $this->new44model->get_more_services(3,42); // category_id, package_id
        $this->load->view('new44/email_signature',$data);
    }
    public function email_templates(){
        $data['package_detail'] = $this->new44model->get_more_services(3,23); // category_id, package_id
        $this->load->view('new44/email_templates',$data);
    }
    public function market_book_cover_design(){
        $data['package_detail'] = $this->new44model->get_more_services(1,17); // category_id, package_id
        $this->load->view('new44/market_book_cover_design',$data);
    }
    public function market_brochure_design(){
        $data['package_detail'] = $this->new44model->get_more_services(1,1); // category_id, package_id
        $this->load->view('new44/market_brochure_design',$data);
    }
    public function market_bumper_sticker(){
        $data['package_detail'] = $this->new44model->get_more_services(1,9); // category_id, package_id
        $this->load->view('new44/market_bumper_sticker',$data);
    }
    public function market_catalog_design(){
        $data['package_detail'] = $this->new44model->get_more_services(1,13); // category_id, package_id
        $this->load->view('new44/market_catalog_design',$data);
    }
    public function market_cddvd_cover(){
        $data['package_detail'] = $this->new44model->get_more_services(1,12); // category_id, package_id
        $this->load->view('new44/market_cddvd_cover',$data);
    }
    public function market_flyer(){
        $data['package_detail'] = $this->new44model->get_more_services(1,3); // category_id, package_id
        $this->load->view('new44/market_flyer',$data);
    }
    public function market_illustration(){
        $data['package_detail'] = $this->new44model->get_more_services(1,14); // category_id, package_id
        $this->load->view('new44/market_illustration',$data);
    }
    public function market_invitation_card(){
        $data['package_detail'] = $this->new44model->get_more_services(1,5); // category_id, package_id
        $this->load->view('new44/market_invitation_card',$data);
    }
    public function market_magazing_cover(){
        $data['package_detail'] = $this->new44model->get_more_services(1,15); // category_id, package_id
        $this->load->view('new44/market_magazing_cover',$data);
    }
    public function market_member_card_design(){
        $data['package_detail'] = $this->new44model->get_more_services(1,6); // category_id, package_id
        $this->load->view('new44/market_member_card_design',$data);
    }
    public function market_menu_design(){
        $data['package_detail'] = $this->new44model->get_more_services(1,8); // category_id, package_id
        $this->load->view('new44/market_menu_design',$data);
    }
    public function market_postcard_design(){
        $data['package_detail'] = $this->new44model->get_more_services(1,10); // category_id, package_id
        $this->load->view('new44/market_postcard_design',$data);
    }
    public function market_poster_design(){
        $data['package_detail'] = $this->new44model->get_more_services(1,4); // category_id, package_id
        $this->load->view('new44/market_poster_design',$data);
    }
    public function market_powerpoint_slide(){
        $data['package_detail'] = $this->new44model->get_more_services(1,7); // category_id, package_id
        $this->load->view('new44/market_powerpoint_slide',$data);
    }
    public function market_product_label(){
        $data['package_detail'] = $this->new44model->get_more_services(1,11); // category_id, package_id
        $this->load->view('new44/market_product_label',$data);
    }
    public function market_product_pack(){
        $data['package_detail'] = $this->new44model->get_more_services(1,16); // category_id, package_id
        $this->load->view('new44/market_product_pack',$data);
    }
    public function market_social_media(){
        $data['package_detail'] = $this->new44model->get_more_services(1,2); // category_id, package_id
        $this->load->view('new44/market_social_media',$data);
    }
    public function market_sticker_design(){
        $data['package_detail'] = $this->new44model->get_more_services(1,18); // category_id, package_id
        $this->load->view('new44/market_sticker_design',$data);
    }
    public function logo_animated_design(){
        $data['package_detail'] = $this->new44model->get_more_services(2,19); // category_id, package_id
        $this->load->view('new44/logo_animated_design',$data);
    }
    public function logo_redesign(){
        $data['package_detail'] = $this->new44model->get_more_services(2,20); // category_id, package_id
        $this->load->view('new44/logo_redesign',$data);
    }
    public function logo_grayscale(){
        $data['package_detail'] = $this->new44model->get_more_services(2,21); // category_id, package_id
        $this->load->view('new44/logo_grayscale',$data);
    }
    public function merch_bookmark_design(){
        $data['package_detail'] = $this->new44model->get_more_services(5,29); // category_id, package_id
        $this->load->view('new44/merch_bookmark_design',$data);
    }
    public function merch_door_hanger_design(){
        $data['package_detail'] = $this->new44model->get_more_services(5,33); // category_id, package_id
        $this->load->view('new44/merch_door_hanger_design',$data);
    }
    public function merch_folder_design(){
        $data['package_detail'] = $this->new44model->get_more_services(5,31); // category_id, package_id
        $this->load->view('new44/merch_folder_design',$data);
    }
    public function merch_merchandise_design(){
        $data['package_detail'] = $this->new44model->get_more_services(5,32); // category_id, package_id
        $this->load->view('new44/merch_merchandise_design',$data);
    }
    public function merch_screen_wallpaper_design(){
        $data['package_detail'] = $this->new44model->get_more_services(5,34); // category_id, package_id
        $this->load->view('new44/merch_screen_wallpaper_design',$data);
    }
    public function merch_signage_design(){
        $data['package_detail'] = $this->new44model->get_more_services(5,30); // category_id, package_id
        $this->load->view('new44/merch_signage_design',$data);
    }
    public function merch_tshirt_design(){
        $data['package_detail'] = $this->new44model->get_more_services(5,28); // category_id, package_id
        $this->load->view('new44/merch_tshirt_design',$data);
    }
    public function stat_business_card_design(){
        $data['package_detail'] = $this->new44model->get_more_services(6,36); // category_id, package_id
        $this->load->view('new44/stat_business_card_design',$data);
    }
    public function stat_complementary_slip(){
        $data['package_detail'] = $this->new44model->get_more_services(6,39); // category_id, package_id
        $this->load->view('new44/stat_complementary_slip',$data);
    }
    public function stat_electronic_letter(){
        $data['package_detail'] = $this->new44model->get_more_services(6,44); // category_id, package_id
        $this->load->view('new44/stat_electronic_letter',$data);
    }
    public function stat_envelope(){
        $data['package_detail'] = $this->new44model->get_more_services(6,38); // category_id, package_id
        $this->load->view('new44/stat_envelope',$data);
    }
    public function stat_fax_template(){
        $data['package_detail'] = $this->new44model->get_more_services(6,40); // category_id, package_id
        $this->load->view('new44/stat_fax_template',$data);
    }
    public function stat_letterhead(){
        $data['package_detail'] = $this->new44model->get_more_services(6,37); // category_id, package_id
        $this->load->view('new44/stat_letterhead',$data);
    }
    public function stat_notepad(){
        $data['package_detail'] = $this->new44model->get_more_services(6,43); // category_id, package_id
        $this->load->view('new44/stat_notepad',$data);
    }
    public function stat_stationary(){
        $data['package_detail'] = $this->new44model->get_more_services(6,35); // category_id, package_id
        $this->load->view('new44/stat_stationary',$data);
    }
    public function web_anim_banner(){
        $data['package_detail'] = $this->new44model->get_more_services(4,25); // category_id, package_id
        $this->load->view('new44/web_anim_banner',$data);
    }
    public function web_anim_header(){
        $data['package_detail'] = $this->new44model->get_more_services(4,41); // category_id, package_id
        $this->load->view('new44/web_anim_header',$data);
    }
    public function web_favicon_design(){
        $data['package_detail'] = $this->new44model->get_more_services(4,27); // category_id, package_id
        $this->load->view('new44/web_favicon_design',$data);
    }
    public function web_icon_design(){
        $data['package_detail'] = $this->new44model->get_more_services(4,26); // category_id, package_id
        $this->load->view('new44/web_icon_design',$data);
    }
    public function web_landing_page(){
        $data['package_detail'] = $this->new44model->get_more_services(4,24); // category_id, package_id
        $this->load->view('new44/web_landing_page',$data);
    }
    
}
/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */